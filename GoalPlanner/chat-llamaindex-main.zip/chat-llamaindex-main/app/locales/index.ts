import en from "./en";

import type { LocaleType } from "./en";
export type { LocaleType } from "./en";

export default en as LocaleType;
