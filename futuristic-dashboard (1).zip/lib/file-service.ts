import fs from "fs"
import path from "path"
import { promisify } from "util"
import mime from "mime-types"

const stat = promisify(fs.stat)
const readdir = promisify(fs.readdir)
const readFile = promisify(fs.readFile)
const unlink = promisify(fs.unlink)
const rename = promisify(fs.rename)
const mkdir = promisify(fs.mkdir)

export interface FileInfo {
  name: string
  path: string
  size: number
  type: string
  extension: string
  createdAt: Date
  updatedAt: Date
  isDirectory: boolean
  preview?: string
}

// Get the uploads directory path
const getUploadsDir = () => {
  return path.join(process.cwd(), "uploads")
}

// Ensure the uploads directory exists
const ensureUploadsDir = async () => {
  const uploadsDir = getUploadsDir()
  try {
    await stat(uploadsDir)
  } catch (error) {
    await mkdir(uploadsDir, { recursive: true })
  }
  return uploadsDir
}

// List all files in the uploads directory
export const listFiles = async (subDir = ""): Promise<FileInfo[]> => {
  const uploadsDir = await ensureUploadsDir()
  const targetDir = path.join(uploadsDir, subDir)

  try {
    await stat(targetDir)
  } catch (error) {
    throw new Error(`Directory not found: ${subDir}`)
  }

  const files = await readdir(targetDir)
  const fileInfoPromises = files.map(async (file) => {
    const filePath = path.join(targetDir, file)
    const stats = await stat(filePath)
    const isDirectory = stats.isDirectory()
    const extension = path.extname(file).toLowerCase()

    // Determine file type
    let type = "unknown"
    if (isDirectory) {
      type = "directory"
    } else {
      type = mime.lookup(file) || "application/octet-stream"
    }

    // Generate preview for images
    let preview = undefined
    if (!isDirectory && type.startsWith("image/")) {
      // For security and performance, we'll just indicate that a preview is available
      // The actual preview will be fetched via a separate API call
      preview = `/api/files/${path.join(subDir, file)}/preview`
    }

    return {
      name: file,
      path: path.join(subDir, file),
      size: stats.size,
      type,
      extension,
      createdAt: stats.birthtime,
      updatedAt: stats.mtime,
      isDirectory,
      preview,
    }
  })

  return Promise.all(fileInfoPromises)
}

// Get file content
export const getFileContent = async (filePath: string): Promise<Buffer> => {
  const uploadsDir = await ensureUploadsDir()
  const fullPath = path.join(uploadsDir, filePath)

  try {
    await stat(fullPath)
  } catch (error) {
    throw new Error(`File not found: ${filePath}`)
  }

  return readFile(fullPath)
}

// Delete a file
export const deleteFile = async (filePath: string): Promise<boolean> => {
  const uploadsDir = await ensureUploadsDir()
  const fullPath = path.join(uploadsDir, filePath)

  try {
    await stat(fullPath)
  } catch (error) {
    throw new Error(`File not found: ${filePath}`)
  }

  await unlink(fullPath)
  return true
}

// Rename a file
export const renameFile = async (oldPath: string, newName: string): Promise<FileInfo> => {
  const uploadsDir = await ensureUploadsDir()
  const fullOldPath = path.join(uploadsDir, oldPath)

  try {
    await stat(fullOldPath)
  } catch (error) {
    throw new Error(`File not found: ${oldPath}`)
  }

  const dirName = path.dirname(oldPath)
  const newPath = path.join(dirName, newName)
  const fullNewPath = path.join(uploadsDir, newPath)

  await rename(fullOldPath, fullNewPath)

  const stats = await stat(fullNewPath)
  const isDirectory = stats.isDirectory()
  const extension = path.extname(newName).toLowerCase()

  // Determine file type
  let type = "unknown"
  if (isDirectory) {
    type = "directory"
  } else {
    type = mime.lookup(newName) || "application/octet-stream"
  }

  return {
    name: newName,
    path: newPath,
    size: stats.size,
    type,
    extension,
    createdAt: stats.birthtime,
    updatedAt: stats.mtime,
    isDirectory,
  }
}

// Create a directory
export const createDirectory = async (dirPath: string): Promise<FileInfo> => {
  const uploadsDir = await ensureUploadsDir()
  const fullPath = path.join(uploadsDir, dirPath)

  await mkdir(fullPath, { recursive: true })

  const stats = await stat(fullPath)

  return {
    name: path.basename(dirPath),
    path: dirPath,
    size: stats.size,
    type: "directory",
    extension: "",
    createdAt: stats.birthtime,
    updatedAt: stats.mtime,
    isDirectory: true,
  }
}

// Get file stats
export const getFileStats = async (filePath: string): Promise<FileInfo> => {
  const uploadsDir = await ensureUploadsDir()
  const fullPath = path.join(uploadsDir, filePath)

  try {
    const stats = await stat(fullPath)
    const isDirectory = stats.isDirectory()
    const fileName = path.basename(filePath)
    const extension = path.extname(fileName).toLowerCase()

    // Determine file type
    let type = "unknown"
    if (isDirectory) {
      type = "directory"
    } else {
      type = mime.lookup(fileName) || "application/octet-stream"
    }

    return {
      name: fileName,
      path: filePath,
      size: stats.size,
      type,
      extension,
      createdAt: stats.birthtime,
      updatedAt: stats.mtime,
      isDirectory,
    }
  } catch (error) {
    throw new Error(`File not found: ${filePath}`)
  }
}
