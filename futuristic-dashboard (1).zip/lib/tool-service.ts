import fs from "fs"
import path from "path"
import { exec } from "child_process"
import { promisify } from "util"

const execPromise = promisify(exec)

export interface Tool {
  id: string
  name: string
  description: string
  type: string
  config: Record<string, any>
  code: string
  createdAt: string
  updatedAt: string
}

// Get the tools directory path
const getToolsDir = () => {
  return path.join(process.cwd(), "tools")
}

// Ensure the tools directory exists
const ensureToolsDir = () => {
  const toolsDir = getToolsDir()
  if (!fs.existsSync(toolsDir)) {
    fs.mkdirSync(toolsDir, { recursive: true })
  }
  return toolsDir
}

// Parse tool metadata from file content
const parseToolMetadata = (content: string, filename: string): Tool => {
  // Extract metadata from comments at the top of the file
  const metadataRegex = /\/\*\s*TOOL_METADATA\s*([\s\S]*?)\*\//
  const match = content.match(metadataRegex)

  let metadata: Partial<Tool> = {}

  if (match && match[1]) {
    try {
      metadata = JSON.parse(match[1])
    } catch (e) {
      console.error(`Failed to parse metadata for ${filename}:`, e)
    }
  }

  const fileStats = fs.statSync(path.join(getToolsDir(), filename))

  return {
    id: metadata.id || filename.replace(/\.[^/.]+$/, ""),
    name: metadata.name || filename.replace(/\.[^/.]+$/, "").replace(/_/g, " "),
    description: metadata.description || "No description provided",
    type: metadata.type || getToolType(filename),
    config: metadata.config || {},
    code: content,
    createdAt: metadata.createdAt || fileStats.birthtime.toISOString(),
    updatedAt: metadata.updatedAt || fileStats.mtime.toISOString(),
  }
}

// Determine tool type based on file extension
const getToolType = (filename: string): string => {
  const ext = path.extname(filename).toLowerCase()
  switch (ext) {
    case ".js":
    case ".ts":
      return "javascript"
    case ".py":
      return "python"
    case ".sh":
      return "shell"
    case ".ps1":
      return "powershell"
    default:
      return "unknown"
  }
}

// Fetch all tools from the tools directory
export const fetchTools = async (): Promise<Tool[]> => {
  try {
    const toolsDir = ensureToolsDir()
    const files = fs.readdirSync(toolsDir)

    const tools: Tool[] = []

    for (const file of files) {
      // Skip directories and non-script files
      const filePath = path.join(toolsDir, file)
      if (fs.statSync(filePath).isDirectory()) continue

      const validExtensions = [".js", ".ts", ".py", ".sh", ".ps1"]
      if (!validExtensions.includes(path.extname(file).toLowerCase())) continue

      const content = fs.readFileSync(filePath, "utf-8")
      const tool = parseToolMetadata(content, file)
      tools.push(tool)
    }

    return tools
  } catch (error) {
    console.error("Error fetching tools:", error)
    return []
  }
}

// Execute a tool with the given parameters
export const executeTool = async (toolId: string, params: Record<string, string>): Promise<any> => {
  try {
    const toolsDir = getToolsDir()
    const files = fs.readdirSync(toolsDir)

    // Find the tool file
    const toolFile = files.find((file) => {
      const baseName = file.replace(/\.[^/.]+$/, "")
      return baseName === toolId
    })

    if (!toolFile) {
      throw new Error(`Tool with ID ${toolId} not found`)
    }

    const filePath = path.join(toolsDir, toolFile)
    const content = fs.readFileSync(filePath, "utf-8")
    const tool = parseToolMetadata(content, toolFile)

    const startTime = Date.now()

    // Execute the tool based on its type
    let result
    switch (tool.type) {
      case "javascript":
        result = await executeJavaScriptTool(filePath, params)
        break
      case "python":
        result = await executePythonTool(filePath, params)
        break
      case "shell":
        result = await executeShellTool(filePath, params)
        break
      case "powershell":
        result = await executePowerShellTool(filePath, params)
        break
      default:
        throw new Error(`Unsupported tool type: ${tool.type}`)
    }

    const endTime = Date.now()

    return {
      success: true,
      output: result,
      executionTime: endTime - startTime,
      timestamp: new Date().toISOString(),
    }
  } catch (error) {
    console.error("Error executing tool:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      output: error instanceof Error ? error.message : "Unknown error",
      executionTime: 0,
      timestamp: new Date().toISOString(),
    }
  }
}

// Execute JavaScript/TypeScript tool
const executeJavaScriptTool = async (filePath: string, params: Record<string, string>): Promise<string> => {
  // Create a temporary file with the parameters
  const paramsPath = path.join(process.cwd(), "temp", `params_${Date.now()}.json`)

  // Ensure temp directory exists
  const tempDir = path.join(process.cwd(), "temp")
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true })
  }

  fs.writeFileSync(paramsPath, JSON.stringify(params))

  try {
    const { stdout, stderr } = await execPromise(`node ${filePath} ${paramsPath}`)
    if (stderr) {
      console.warn("Tool execution warning:", stderr)
    }
    return stdout
  } finally {
    // Clean up the temporary file
    if (fs.existsSync(paramsPath)) {
      fs.unlinkSync(paramsPath)
    }
  }
}

// Execute Python tool
const executePythonTool = async (filePath: string, params: Record<string, string>): Promise<string> => {
  // Create a temporary file with the parameters
  const paramsPath = path.join(process.cwd(), "temp", `params_${Date.now()}.json`)

  // Ensure temp directory exists
  const tempDir = path.join(process.cwd(), "temp")
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true })
  }

  fs.writeFileSync(paramsPath, JSON.stringify(params))

  try {
    const { stdout, stderr } = await execPromise(`python ${filePath} ${paramsPath}`)
    if (stderr) {
      console.warn("Tool execution warning:", stderr)
    }
    return stdout
  } finally {
    // Clean up the temporary file
    if (fs.existsSync(paramsPath)) {
      fs.unlinkSync(paramsPath)
    }
  }
}

// Execute Shell script
const executeShellTool = async (filePath: string, params: Record<string, string>): Promise<string> => {
  // Create a temporary file with the parameters
  const paramsPath = path.join(process.cwd(), "temp", `params_${Date.now()}.json`)

  // Ensure temp directory exists
  const tempDir = path.join(process.cwd(), "temp")
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true })
  }

  fs.writeFileSync(paramsPath, JSON.stringify(params))

  try {
    // Make sure the script is executable
    await execPromise(`chmod +x ${filePath}`)

    const { stdout, stderr } = await execPromise(`${filePath} ${paramsPath}`)
    if (stderr) {
      console.warn("Tool execution warning:", stderr)
    }
    return stdout
  } finally {
    // Clean up the temporary file
    if (fs.existsSync(paramsPath)) {
      fs.unlinkSync(paramsPath)
    }
  }
}

// Execute PowerShell script
const executePowerShellTool = async (filePath: string, params: Record<string, string>): Promise<string> => {
  // Create a temporary file with the parameters
  const paramsPath = path.join(process.cwd(), "temp", `params_${Date.now()}.json`)

  // Ensure temp directory exists
  const tempDir = path.join(process.cwd(), "temp")
  if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true })
  }

  fs.writeFileSync(paramsPath, JSON.stringify(params))

  try {
    const { stdout, stderr } = await execPromise(`powershell -ExecutionPolicy Bypass -File ${filePath} ${paramsPath}`)
    if (stderr) {
      console.warn("Tool execution warning:", stderr)
    }
    return stdout
  } finally {
    // Clean up the temporary file
    if (fs.existsSync(paramsPath)) {
      fs.unlinkSync(paramsPath)
    }
  }
}

// Create a new tool
export const createTool = async (
  name: string,
  description: string,
  type: string,
  code: string,
  config: Record<string, any>,
): Promise<Tool> => {
  const toolsDir = ensureToolsDir()

  // Generate a safe filename
  const safeName = name.toLowerCase().replace(/[^a-z0-9_]/g, "_")
  let extension = ".js"

  switch (type) {
    case "python":
      extension = ".py"
      break
    case "shell":
      extension = ".sh"
      break
    case "powershell":
      extension = ".ps1"
      break
  }

  const filename = `${safeName}${extension}`
  const filePath = path.join(toolsDir, filename)

  // Check if file already exists
  if (fs.existsSync(filePath)) {
    throw new Error(`A tool with the name ${name} already exists`)
  }

  // Create metadata
  const metadata = {
    id: safeName,
    name,
    description,
    type,
    config,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  // Add metadata to the code
  const codeWithMetadata = `/* TOOL_METADATA
${JSON.stringify(metadata, null, 2)}
*/

${code}`

  // Write the file
  fs.writeFileSync(filePath, codeWithMetadata)

  // If it's a shell script, make it executable
  if (type === "shell") {
    await execPromise(`chmod +x ${filePath}`)
  }

  return {
    ...metadata,
    code,
  }
}

// Update an existing tool
export const updateTool = async (id: string, updates: Partial<Tool>): Promise<Tool> => {
  const toolsDir = getToolsDir()
  const files = fs.readdirSync(toolsDir)

  // Find the tool file
  const toolFile = files.find((file) => {
    const baseName = file.replace(/\.[^/.]+$/, "")
    return baseName === id
  })

  if (!toolFile) {
    throw new Error(`Tool with ID ${id} not found`)
  }

  const filePath = path.join(toolsDir, toolFile)
  const content = fs.readFileSync(filePath, "utf-8")
  const tool = parseToolMetadata(content, toolFile)

  // Update the tool
  const updatedTool = {
    ...tool,
    ...updates,
    updatedAt: new Date().toISOString(),
  }

  // Create metadata
  const metadata = {
    id: updatedTool.id,
    name: updatedTool.name,
    description: updatedTool.description,
    type: updatedTool.type,
    config: updatedTool.config,
    createdAt: updatedTool.createdAt,
    updatedAt: updatedTool.updatedAt,
  }

  // Add metadata to the code
  const codeWithMetadata = `/* TOOL_METADATA
${JSON.stringify(metadata, null, 2)}
*/

${updatedTool.code}`

  // Write the file
  fs.writeFileSync(filePath, codeWithMetadata)

  return updatedTool
}

// Delete a tool
export const deleteTool = async (id: string): Promise<boolean> => {
  const toolsDir = getToolsDir()
  const files = fs.readdirSync(toolsDir)

  // Find the tool file
  const toolFile = files.find((file) => {
    const baseName = file.replace(/\.[^/.]+$/, "")
    return baseName === id
  })

  if (!toolFile) {
    throw new Error(`Tool with ID ${id} not found`)
  }

  const filePath = path.join(toolsDir, toolFile)
  fs.unlinkSync(filePath)

  return true
}
