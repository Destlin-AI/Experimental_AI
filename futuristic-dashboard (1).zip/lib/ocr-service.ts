import { createWorker } from "tesseract.js"
import sharp from "sharp"
import path from "path"
import fs from "fs"
import { promisify } from "util"

const writeFile = promisify(fs.writeFile)
const mkdir = promisify(fs.mkdir)

// Ensure the temp directory exists
const ensureTempDir = async () => {
  const tempDir = path.join(process.cwd(), "temp")
  try {
    await promisify(fs.stat)(tempDir)
  } catch (error) {
    await mkdir(tempDir, { recursive: true })
  }
  return tempDir
}

// Process image with OCR
export const processImageWithOCR = async (
  imageBuffer: Buffer,
  options: {
    language?: string
    enhanceImage?: boolean
    ocrEngine?: string
  } = {},
): Promise<{
  text: string
  confidence: number
  words: Array<{
    text: string
    confidence: number
    bbox: { x0: number; y0: number; x1: number; y1: number }
  }>
}> => {
  const { language = "eng", enhanceImage = true, ocrEngine = "standard" } = options

  let processedImageBuffer = imageBuffer

  // Enhance image if requested
  if (enhanceImage) {
    processedImageBuffer = await enhanceImageForOCR(imageBuffer)
  }

  // Save the processed image to a temporary file
  const tempDir = await ensureTempDir()
  const tempImagePath = path.join(tempDir, `ocr_input_${Date.now()}.png`)
  await writeFile(tempImagePath, processedImageBuffer)

  // Initialize Tesseract worker
  const worker = await createWorker({
    logger: (m) => console.log(m),
  })

  try {
    // Load language data
    await worker.loadLanguage(language)
    await worker.initialize(language)

    // Set OCR engine mode based on the selected engine
    // 0 - Legacy engine only
    // 1 - Neural nets LSTM engine only
    // 2 - Legacy + LSTM engines
    // 3 - Default, based on what is available
    let engineMode = 3
    if (ocrEngine === "legacy") {
      engineMode = 0
    } else if (ocrEngine === "advanced") {
      engineMode = 1
    }

    await worker.setParameters({
      tessedit_ocr_engine_mode: engineMode,
    })

    // Recognize text
    const { data } = await worker.recognize(tempImagePath)

    // Clean up
    await worker.terminate()
    try {
      fs.unlinkSync(tempImagePath)
    } catch (error) {
      console.error("Error deleting temporary file:", error)
    }

    return {
      text: data.text,
      confidence: data.confidence,
      words: data.words.map((word: any) => ({
        text: word.text,
        confidence: word.confidence,
        bbox: word.bbox,
      })),
    }
  } catch (error) {
    // Clean up on error
    await worker.terminate()
    try {
      fs.unlinkSync(tempImagePath)
    } catch (err) {
      console.error("Error deleting temporary file:", err)
    }

    throw error
  }
}

// Enhance image for better OCR results
const enhanceImageForOCR = async (imageBuffer: Buffer): Promise<Buffer> => {
  return (
    sharp(imageBuffer)
      // Convert to grayscale
      .grayscale()
      // Increase contrast
      .normalize()
      // Apply mild sharpening
      .sharpen()
      // Ensure consistent format
      .png()
      .toBuffer()
  )
}

// Extract text from a file path
export const extractTextFromFile = async (
  filePath: string,
  options: {
    language?: string
    enhanceImage?: boolean
    ocrEngine?: string
  } = {},
): Promise<{
  text: string
  confidence: number
  words: Array<{
    text: string
    confidence: number
    bbox: { x0: number; y0: number; x1: number; y1: number }
  }>
}> => {
  const imageBuffer = await promisify(fs.readFile)(filePath)
  return processImageWithOCR(imageBuffer, options)
}
