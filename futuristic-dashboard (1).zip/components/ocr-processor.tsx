"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { FileText, Upload, ImageIcon, RefreshCw, Copy, Download, Settings, Check, X, Sparkles } from "lucide-react"

interface OCRProcessorProps {
  standalone?: boolean
}

export function OCRProcessor({ standalone = false }: OCRProcessorProps) {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("upload")
  const [isProcessing, setIsProcessing] = useState(false)
  const [recognizedText, setRecognizedText] = useState("")
  const [confidence, setConfidence] = useState(0)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [language, setLanguage] = useState("eng")
  const [enhanceImage, setEnhanceImage] = useState(true)
  const [ocrEngine, setOcrEngine] = useState("standard")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file (JPEG, PNG, etc.)",
        variant: "destructive",
      })
      return
    }

    setSelectedFile(file)

    // Create preview
    const reader = new FileReader()
    reader.onload = () => {
      setImagePreview(reader.result as string)
      setRecognizedText("")
      setConfidence(0)
    }
    reader.readAsDataURL(file)
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()

    const file = e.dataTransfer.files?.[0]
    if (!file) return

    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image file (JPEG, PNG, etc.)",
        variant: "destructive",
      })
      return
    }

    setSelectedFile(file)

    // Create preview
    const reader = new FileReader()
    reader.onload = () => {
      setImagePreview(reader.result as string)
      setRecognizedText("")
      setConfidence(0)
    }
    reader.readAsDataURL(file)
  }

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
  }

  const processImage = async () => {
    if (!imagePreview || !selectedFile) return

    setIsProcessing(true)
    setRecognizedText("")
    setConfidence(0)

    try {
      // Create form data for the API request
      const formData = new FormData()
      formData.append("file", selectedFile)
      formData.append("language", language)
      formData.append("enhanceImage", enhanceImage.toString())
      formData.append("ocrEngine", ocrEngine)

      // Send the request to the OCR API
      const response = await fetch("/api/ocr/scan", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`OCR processing failed: ${response.statusText}`)
      }

      const result = await response.json()

      if (result.success) {
        setRecognizedText(result.text)
        setConfidence(result.confidence)

        toast({
          title: "OCR processing complete",
          description: `Text extracted with ${Math.round(result.confidence)}% confidence`,
        })
      } else {
        throw new Error(result.error || "OCR processing failed")
      }
    } catch (error) {
      console.error("Error processing image:", error)
      toast({
        title: "Processing failed",
        description: error instanceof Error ? error.message : "There was an error processing the image",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(recognizedText)
    toast({
      title: "Copied to clipboard",
      description: "The recognized text has been copied to clipboard",
    })
  }

  const downloadText = () => {
    const blob = new Blob([recognizedText], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `ocr-result-${new Date().toISOString().replace(/:/g, "-")}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Downloaded",
      description: "The recognized text has been downloaded",
    })
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  return (
    <Card className={standalone ? "bg-slate-900/50 border-slate-700/50 backdrop-blur-sm" : ""}>
      <CardHeader className={standalone ? "border-b border-slate-700/50 pb-3" : "pb-2"}>
        <div className="flex items-center justify-between">
          <CardTitle className="text-slate-100 flex items-center text-base">
            <FileText className="mr-2 h-5 w-5 text-purple-500" />
            OCR Processor
          </CardTitle>
          <Badge variant="outline" className="bg-slate-800/50 text-purple-400 border-purple-500/50">
            <Sparkles className="h-3 w-3 mr-1" />
            AI Powered
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="bg-slate-800/50 p-1 mb-4">
            <TabsTrigger
              value="upload"
              className="data-[state=active]:bg-slate-700 data-[state=active]:text-purple-400"
            >
              Upload
            </TabsTrigger>
            <TabsTrigger
              value="result"
              className="data-[state=active]:bg-slate-700 data-[state=active]:text-purple-400"
              disabled={!recognizedText}
            >
              Result
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="data-[state=active]:bg-slate-700 data-[state=active]:text-purple-400"
            >
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="m-0">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div
                  className={`border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center text-center h-64 ${
                    imagePreview ? "border-purple-500/50" : "border-slate-700"
                  }`}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                >
                  {imagePreview ? (
                    <img
                      src={imagePreview || "/placeholder.svg"}
                      alt="Preview"
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <>
                      <ImageIcon className="h-12 w-12 text-slate-500 mb-4" />
                      <p className="text-slate-300 mb-2">Drag and drop an image here</p>
                      <p className="text-slate-500 text-sm mb-4">or</p>
                      <Button
                        variant="outline"
                        className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50"
                        onClick={triggerFileInput}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Browse Files
                      </Button>
                    </>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </div>

                <div className="flex justify-between">
                  {imagePreview && (
                    <Button
                      variant="outline"
                      className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50"
                      onClick={() => {
                        setImagePreview(null)
                        setRecognizedText("")
                        setConfidence(0)
                        setSelectedFile(null)
                      }}
                    >
                      <X className="h-4 w-4 mr-2" />
                      Clear
                    </Button>
                  )}
                  <Button
                    className="bg-purple-600 hover:bg-purple-700 ml-auto"
                    disabled={!imagePreview || isProcessing}
                    onClick={processImage}
                  >
                    {isProcessing ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-4 w-4 mr-2" />
                        Extract Text
                      </>
                    )}
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-slate-800/50 rounded-lg border border-slate-700/50 p-4">
                  <h3 className="text-base font-medium text-slate-200 mb-2">OCR Processing</h3>
                  <p className="text-sm text-slate-400 mb-4">
                    Upload an image containing text, and our AI-powered OCR will extract the text content.
                  </p>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-400">Selected Language:</span>
                      <Badge className="bg-slate-700 text-slate-300">
                        {language === "eng"
                          ? "English"
                          : language === "fra"
                            ? "French"
                            : language === "deu"
                              ? "German"
                              : language === "spa"
                                ? "Spanish"
                                : language}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-400">Image Enhancement:</span>
                      <Badge
                        className={enhanceImage ? "bg-green-600/20 text-green-400" : "bg-slate-700 text-slate-300"}
                      >
                        {enhanceImage ? <Check className="h-3 w-3 mr-1" /> : <X className="h-3 w-3 mr-1" />}
                        {enhanceImage ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-slate-400">OCR Engine:</span>
                      <Badge className="bg-slate-700 text-slate-300">
                        {ocrEngine === "standard"
                          ? "Standard"
                          : ocrEngine === "advanced"
                            ? "Advanced"
                            : ocrEngine === "legacy"
                              ? "Legacy"
                              : ocrEngine}
                      </Badge>
                    </div>
                  </div>
                </div>

                {recognizedText && (
                  <div className="bg-slate-800/50 rounded-lg border border-slate-700/50 p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-base font-medium text-slate-200">Processing Results</h3>
                      <Badge
                        className={`${
                          confidence >= 90
                            ? "bg-green-600/20 text-green-400"
                            : confidence >= 70
                              ? "bg-amber-600/20 text-amber-400"
                              : "bg-red-600/20 text-red-400"
                        }`}
                      >
                        {confidence}% Confidence
                      </Badge>
                    </div>

                    <div className="flex space-x-2 mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50"
                        onClick={() => setActiveTab("result")}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        View Full Text
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50"
                        onClick={copyToClipboard}
                      >
                        <Copy className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50"
                        onClick={downloadText}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="result" className="m-0">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-medium text-slate-200">Extracted Text</h3>
                <div className="flex items-center space-x-2">
                  <Badge
                    className={`${
                      confidence >= 90
                        ? "bg-green-600/20 text-green-400"
                        : confidence >= 70
                          ? "bg-amber-600/20 text-amber-400"
                          : "bg-red-600/20 text-red-400"
                    }`}
                  >
                    {confidence}% Confidence
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50"
                    onClick={copyToClipboard}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50"
                    onClick={downloadText}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>

              <div className="bg-slate-800/30 rounded-lg border border-slate-700/50 p-4 min-h-[300px]">
                <pre className="whitespace-pre-wrap text-slate-300 font-mono text-sm">{recognizedText}</pre>
              </div>

              <div className="flex justify-between">
                <Button
                  variant="outline"
                  className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50"
                  onClick={() => setActiveTab("upload")}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Another Image
                </Button>
                <Button
                  className="bg-purple-600 hover:bg-purple-700"
                  onClick={processImage}
                  disabled={!imagePreview || isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Process Again
                    </>
                  )}
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="m-0">
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="language" className="text-slate-300">
                  OCR Language
                </Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger id="language" className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="eng">English</SelectItem>
                    <SelectItem value="fra">French</SelectItem>
                    <SelectItem value="deu">German</SelectItem>
                    <SelectItem value="spa">Spanish</SelectItem>
                    <SelectItem value="ita">Italian</SelectItem>
                    <SelectItem value="por">Portuguese</SelectItem>
                    <SelectItem value="rus">Russian</SelectItem>
                    <SelectItem value="jpn">Japanese</SelectItem>
                    <SelectItem value="kor">Korean</SelectItem>
                    <SelectItem value="chi_sim">Chinese (Simplified)</SelectItem>
                    <SelectItem value="chi_tra">Chinese (Traditional)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="engine" className="text-slate-300">
                  OCR Engine
                </Label>
                <Select value={ocrEngine} onValueChange={setOcrEngine}>
                  <SelectTrigger id="engine" className="bg-slate-800 border-slate-700">
                    <SelectValue placeholder="Select OCR engine" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="advanced">Advanced (AI-enhanced)</SelectItem>
                    <SelectItem value="legacy">Legacy</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500 mt-1">
                  Advanced engine uses AI for better accuracy but may be slower.
                </p>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enhance" className="text-slate-300">
                    Image Enhancement
                  </Label>
                  <p className="text-xs text-slate-500">Pre-process images to improve OCR accuracy</p>
                </div>
                <Switch id="enhance" checked={enhanceImage} onCheckedChange={setEnhanceImage} />
              </div>

              <div className="space-y-2">
                <Label className="text-slate-300">Advanced Settings</Label>
                <div className="bg-slate-800/50 rounded-lg border border-slate-700/50 p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="text-sm font-medium text-slate-300">Page Segmentation</h4>
                      <p className="text-xs text-slate-500">How to split the image into regions</p>
                    </div>
                    <Select defaultValue="auto">
                      <SelectTrigger className="w-40 bg-slate-800 border-slate-700">
                        <SelectValue placeholder="Select mode" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-slate-700">
                        <SelectItem value="auto">Auto</SelectItem>
                        <SelectItem value="single_block">Single Block</SelectItem>
                        <SelectItem value="single_column">Single Column</SelectItem>
                        <SelectItem value="single_line">Single Line</SelectItem>
                        <SelectItem value="single_word">Single Word</SelectItem>
                        <SelectItem value="sparse_text">Sparse Text</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="dpi" className="text-sm text-slate-300">
                        DPI (72-300)
                      </Label>
                      <Input
                        id="dpi"
                        type="number"
                        defaultValue="300"
                        min="72"
                        max="300"
                        className="w-20 bg-slate-800 border-slate-700 text-slate-100"
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="threshold" className="text-sm text-slate-300">
                        Threshold (0-255)
                      </Label>
                      <Input
                        id="threshold"
                        type="number"
                        defaultValue="128"
                        min="0"
                        max="255"
                        className="w-20 bg-slate-800 border-slate-700 text-slate-100"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="border-t border-slate-700/50 p-4">
        <div className="flex items-center justify-between w-full">
          <Button variant="outline" className="border-slate-700 bg-slate-800/50 hover:bg-slate-700/50">
            <Settings className="h-4 w-4 mr-2" />
            Advanced Options
          </Button>
          <Button
            className="bg-purple-600 hover:bg-purple-700"
            onClick={processImage}
            disabled={!imagePreview || isProcessing}
          >
            {isProcessing ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Extract Text
              </>
            )}
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}
