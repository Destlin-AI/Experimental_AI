"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useToast } from "@/components/ui/use-toast"
import {
  File,
  Folder,
  ImageIcon,
  FileText,
  FileCode,
  FileArchive,
  FileAudio,
  FileVideo,
  MoreVertical,
  Trash2,
  Edit,
  Download,
  Eye,
  FolderPlus,
  RefreshCw,
  Search,
  ArrowUp,
  ArrowLeft,
} from "lucide-react"
import { formatDistanceToNow } from "date-fns"

interface FileInfo {
  name: string
  path: string
  size: number
  type: string
  extension: string
  createdAt: Date
  updatedAt: Date
  isDirectory: boolean
  preview?: string
}

export function UploadsManager() {
  const { toast } = useToast()
  const [files, setFiles] = useState<FileInfo[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPath, setCurrentPath] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedFile, setSelectedFile] = useState<FileInfo | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [showPreview, setShowPreview] = useState(false)
  const [newFolderName, setNewFolderName] = useState("")
  const [showNewFolderDialog, setShowNewFolderDialog] = useState(false)
  const [renameValue, setRenameValue] = useState("")
  const [showRenameDialog, setShowRenameDialog] = useState(false)

  useEffect(() => {
    loadFiles()
  }, [currentPath])

  const loadFiles = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/files?dir=${encodeURIComponent(currentPath)}`)
      if (!response.ok) {
        throw new Error("Failed to fetch files")
      }

      const data = await response.json()
      // Convert date strings to Date objects
      const filesWithDates = data.map((file: any) => ({
        ...file,
        createdAt: new Date(file.createdAt),
        updatedAt: new Date(file.updatedAt),
      }))

      setFiles(filesWithDates)
    } catch (error) {
      console.error("Error loading files:", error)
      toast({
        title: "Error",
        description: "Failed to load files. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const navigateToFolder = (folderPath: string) => {
    setCurrentPath(folderPath)
  }

  const navigateUp = () => {
    if (currentPath === "") return

    const pathParts = currentPath.split("/")
    pathParts.pop()
    setCurrentPath(pathParts.join("/"))
  }

  const handleFileClick = (file: FileInfo) => {
    if (file.isDirectory) {
      navigateToFolder(file.path)
    } else {
      setSelectedFile(file)

      if (file.type.startsWith("image/")) {
        setPreviewUrl(`/api/files/${encodeURIComponent(file.path)}?action=preview`)
        setShowPreview(true)
      } else {
        // For non-image files, we'll just download them
        window.open(`/api/files/${encodeURIComponent(file.path)}`, "_blank")
      }
    }
  }

  const downloadFile = (file: FileInfo) => {
    window.open(`/api/files/${encodeURIComponent(file.path)}`, "_blank")
  }

  const previewFile = (file: FileInfo) => {
    if (file.type.startsWith("image/")) {
      setPreviewUrl(`/api/files/${encodeURIComponent(file.path)}?action=preview`)
      setShowPreview(true)
    } else {
      toast({
        title: "Preview not available",
        description: "Preview is only available for image files.",
      })
    }
  }

  const deleteFile = async (file: FileInfo) => {
    try {
      const response = await fetch(`/api/files/${encodeURIComponent(file.path)}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete file")
      }

      toast({
        title: "File deleted",
        description: `${file.name} has been deleted successfully.`,
      })

      loadFiles()
    } catch (error) {
      console.error("Error deleting file:", error)
      toast({
        title: "Error",
        description: "Failed to delete file. Please try again.",
        variant: "destructive",
      })
    }
  }

  const createFolder = async () => {
    if (!newFolderName.trim()) {
      toast({
        title: "Error",
        description: "Folder name cannot be empty.",
        variant: "destructive",
      })
      return
    }

    try {
      const folderPath = currentPath ? `${currentPath}/${newFolderName}` : newFolderName

      const response = await fetch("/api/files", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ path: folderPath }),
      })

      if (!response.ok) {
        throw new Error("Failed to create folder")
      }

      toast({
        title: "Folder created",
        description: `${newFolderName} has been created successfully.`,
      })

      setNewFolderName("")
      setShowNewFolderDialog(false)
      loadFiles()
    } catch (error) {
      console.error("Error creating folder:", error)
      toast({
        title: "Error",
        description: "Failed to create folder. Please try again.",
        variant: "destructive",
      })
    }
  }

  const startRename = (file: FileInfo) => {
    setSelectedFile(file)
    setRenameValue(file.name)
    setShowRenameDialog(true)
  }

  const renameFile = async () => {
    if (!selectedFile || !renameValue.trim()) {
      toast({
        title: "Error",
        description: "File name cannot be empty.",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch(`/api/files/${encodeURIComponent(selectedFile.path)}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ newName: renameValue }),
      })

      if (!response.ok) {
        throw new Error("Failed to rename file")
      }

      toast({
        title: "File renamed",
        description: `File has been renamed to ${renameValue} successfully.`,
      })

      setShowRenameDialog(false)
      loadFiles()
    } catch (error) {
      console.error("Error renaming file:", error)
      toast({
        title: "Error",
        description: "Failed to rename file. Please try again.",
        variant: "destructive",
      })
    }
  }

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"

    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  const getFileIcon = (file: FileInfo) => {
    if (file.isDirectory) {
      return <Folder className="h-6 w-6 text-blue-500" />
    }

    if (file.type.startsWith("image/")) {
      return <ImageIcon className="h-6 w-6 text-purple-500" />
    }

    if (file.type.startsWith("text/")) {
      return <FileText className="h-6 w-6 text-green-500" />
    }

    if (
      file.type.includes("javascript") ||
      file.type.includes("json") ||
      file.type.includes("html") ||
      file.type.includes("css")
    ) {
      return <FileCode className="h-6 w-6 text-yellow-500" />
    }

    if (file.type.includes("zip") || file.type.includes("tar") || file.type.includes("compressed")) {
      return <FileArchive className="h-6 w-6 text-red-500" />
    }

    if (file.type.startsWith("audio/")) {
      return <FileAudio className="h-6 w-6 text-pink-500" />
    }

    if (file.type.startsWith("video/")) {
      return <FileVideo className="h-6 w-6 text-cyan-500" />
    }

    return <File className="h-6 w-6 text-slate-500" />
  }

  const filteredFiles = files.filter((file) => file.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Folder className="mr-2 h-5 w-5 text-blue-500" />
            <span>File Manager</span>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-slate-700/50"
              onClick={loadFiles}
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-slate-700/50"
              onClick={() => setShowNewFolderDialog(true)}
            >
              <FolderPlus className="h-4 w-4 mr-2" />
              New Folder
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <Input
                placeholder="Search files..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 bg-slate-800/50 border-slate-700"
              />
            </div>
            {currentPath && (
              <Button
                variant="outline"
                size="icon"
                className="bg-slate-800/50 border-slate-700 text-slate-300 hover:bg-slate-700/50"
                onClick={navigateUp}
              >
                <ArrowUp className="h-4 w-4" />
              </Button>
            )}
          </div>

          <div className="bg-slate-800/30 rounded-md p-2 flex items-center space-x-1 overflow-x-auto">
            <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={() => setCurrentPath("")}>
              <Folder className="h-3 w-3 mr-1" />
              root
            </Button>

            {currentPath
              .split("/")
              .filter(Boolean)
              .map((part, index, array) => (
                <div key={index} className="flex items-center">
                  <ArrowLeft className="h-3 w-3 text-slate-500 rotate-180" />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 px-2 text-xs"
                    onClick={() => {
                      const path = array.slice(0, index + 1).join("/")
                      setCurrentPath(path)
                    }}
                  >
                    {part}
                  </Button>
                </div>
              ))}
          </div>

          {loading ? (
            <div className="flex justify-center py-8">
              <RefreshCw className="h-8 w-8 animate-spin text-slate-500" />
            </div>
          ) : filteredFiles.length > 0 ? (
            <ScrollArea className="h-[400px]">
              <div className="space-y-1">
                {filteredFiles.map((file) => (
                  <div
                    key={file.path}
                    className="flex items-center justify-between p-2 rounded-md hover:bg-slate-800/50 cursor-pointer"
                    onClick={() => handleFileClick(file)}
                  >
                    <div className="flex items-center space-x-3">
                      {getFileIcon(file)}
                      <div>
                        <div className="font-medium text-slate-200">{file.name}</div>
                        <div className="text-xs text-slate-400">
                          {file.isDirectory
                            ? "Folder"
                            : `${formatFileSize(file.size)} • ${formatDistanceToNow(file.updatedAt, { addSuffix: true })}`}
                        </div>
                      </div>
                    </div>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-slate-900 border-slate-700">
                        {!file.isDirectory && (
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation()
                              downloadFile(file)
                            }}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </DropdownMenuItem>
                        )}

                        {file.type.startsWith("image/") && (
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation()
                              previewFile(file)
                            }}
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            Preview
                          </DropdownMenuItem>
                        )}

                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation()
                            startRename(file)
                          }}
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Rename
                        </DropdownMenuItem>

                        <DropdownMenuItem
                          className="text-red-500"
                          onClick={(e) => {
                            e.stopPropagation()
                            deleteFile(file)
                          }}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            </ScrollArea>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-slate-500">
              <Folder className="h-12 w-12 mb-2" />
              {searchQuery ? <p>No files matching your search</p> : <p>This folder is empty</p>}
            </div>
          )}
        </div>

        {/* Preview Dialog */}
        <Dialog open={showPreview} onOpenChange={setShowPreview}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>{selectedFile?.name}</DialogTitle>
            </DialogHeader>
            {previewUrl && (
              <div className="flex justify-center">
                <img
                  src={previewUrl || "/placeholder.svg"}
                  alt={selectedFile?.name || "Preview"}
                  className="max-h-[500px] max-w-full object-contain"
                />
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* New Folder Dialog */}
        <Dialog open={showNewFolderDialog} onOpenChange={setShowNewFolderDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Folder</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Input
                  placeholder="Folder name"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  className="bg-slate-800 border-slate-700"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setShowNewFolderDialog(false)}
                  className="bg-slate-800/50 border-slate-700 text-slate-300"
                >
                  Cancel
                </Button>
                <Button onClick={createFolder} className="bg-blue-600 hover:bg-blue-700">
                  Create
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Rename Dialog */}
        <Dialog open={showRenameDialog} onOpenChange={setShowRenameDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Rename {selectedFile?.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Input
                  placeholder="New name"
                  value={renameValue}
                  onChange={(e) => setRenameValue(e.target.value)}
                  className="bg-slate-800 border-slate-700"
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setShowRenameDialog(false)}
                  className="bg-slate-800/50 border-slate-700 text-slate-300"
                >
                  Cancel
                </Button>
                <Button onClick={renameFile} className="bg-blue-600 hover:bg-blue-700">
                  Rename
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
      <CardFooter className="border-t border-slate-700/50 pt-4">
        <div className="w-full flex items-center justify-between text-xs text-slate-400">
          <div>
            {filteredFiles.length} {filteredFiles.length === 1 ? "item" : "items"}
          </div>
          <div>
            {files.filter((f) => !f.isDirectory).reduce((acc, file) => acc + file.size, 0) > 0 && (
              <span>
                Total size:{" "}
                {formatFileSize(files.filter((f) => !f.isDirectory).reduce((acc, file) => acc + file.size, 0))}
              </span>
            )}
          </div>
        </div>
      </CardFooter>
    </Card>
  )
}
