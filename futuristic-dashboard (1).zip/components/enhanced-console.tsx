"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Terminal, X, ChevronRight, Download, Copy, Clock, RefreshCw } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

interface CommandHistory {
  command: string
  output: string
  timestamp: Date
  success: boolean
}

export function EnhancedConsole() {
  const [input, setInput] = useState("")
  const [processing, setProcessing] = useState(false)
  const [commandHistory, setCommandHistory] = useState<CommandHistory[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const outputRef = useRef<HTMLDivElement>(null)

  const availableCommands = [
    "help",
    "clear",
    "echo",
    "ls",
    "cd",
    "pwd",
    "cat",
    "mkdir",
    "rm",
    "cp",
    "mv",
    "grep",
    "find",
    "ps",
    "kill",
    "top",
    "df",
    "du",
    "free",
    "ping",
    "traceroute",
    "netstat",
    "ifconfig",
    "ssh",
    "scp",
    "wget",
    "curl",
    "apt",
    "npm",
    "git",
    "docker",
    "systemctl",
    "journalctl",
  ]

  useEffect(() => {
    // Add welcome message
    setCommandHistory([
      {
        command: "",
        output: 'Welcome to Enhanced Console v1.0.0\nType "help" to see available commands.',
        timestamp: new Date(),
        success: true,
      },
    ])
  }, [])

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight
    }
  }, [commandHistory])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)

    // Show command suggestions
    if (e.target.value) {
      const filtered = availableCommands.filter((cmd) => cmd.startsWith(e.target.value.split(" ")[0]))
      setSuggestions(filtered.slice(0, 5))
      setShowSuggestions(filtered.length > 0)
    } else {
      setShowSuggestions(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Handle up/down arrow for command history
    if (e.key === "ArrowUp") {
      e.preventDefault()
      if (historyIndex < commandHistory.length - 1) {
        const newIndex = historyIndex + 1
        setHistoryIndex(newIndex)
        setInput(commandHistory[commandHistory.length - 1 - newIndex].command)
        setShowSuggestions(false)
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault()
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1
        setHistoryIndex(newIndex)
        setInput(commandHistory[commandHistory.length - 1 - newIndex].command)
      } else if (historyIndex === 0) {
        setHistoryIndex(-1)
        setInput("")
      }
    } else if (e.key === "Tab") {
      e.preventDefault()
      if (suggestions.length > 0) {
        setInput(suggestions[0])
        setShowSuggestions(false)
      }
    }
  }

  const executeCommand = async (cmd: string) => {
    if (!cmd.trim()) return

    setProcessing(true)
    setHistoryIndex(-1)
    setShowSuggestions(false)

    try {
      // Send command to backend API
      const response = await fetch("http://localhost:3000/api/console/execute", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ command: cmd }),
      })

      const result = await response.json()

      setCommandHistory((prev) => [
        ...prev,
        {
          command: cmd,
          output: result.output || "Command executed successfully with no output.",
          timestamp: new Date(),
          success: result.success,
        },
      ])
    } catch (error) {
      console.error("Failed to execute command:", error)
      setCommandHistory((prev) => [
        ...prev,
        {
          command: cmd,
          output: `Error: Failed to execute command. ${error instanceof Error ? error.message : "Unknown error"}`,
          timestamp: new Date(),
          success: false,
        },
      ])
    } finally {
      setProcessing(false)
      setInput("")
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    executeCommand(input)
  }

  const clearConsole = () => {
    setCommandHistory([])
    toast({
      title: "Console Cleared",
      description: "All command history has been cleared.",
    })
  }

  const copyToClipboard = () => {
    const text = commandHistory.map((entry) => `$ ${entry.command}\n${entry.output}`).join("\n\n")

    navigator.clipboard.writeText(text).then(() => {
      toast({
        title: "Copied to Clipboard",
        description: "Console output has been copied to clipboard.",
      })
    })
  }

  const downloadOutput = () => {
    const text = commandHistory.map((entry) => `$ ${entry.command}\n${entry.output}`).join("\n\n")

    const blob = new Blob([text], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `console-output-${new Date().toISOString().slice(0, 10)}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Download Started",
      description: "Console output is being downloaded as a text file.",
    })
  }

  const applySuggestion = (suggestion: string) => {
    setInput(suggestion)
    setShowSuggestions(false)
    inputRef.current?.focus()
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center">
            <Terminal className="mr-2 h-5 w-5" />
            <span>System Console</span>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={clearConsole}>
              <X className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={copyToClipboard}>
              <Copy className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={downloadOutput}>
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </CardTitle>
        <CardDescription>Execute system commands and view output</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="console">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="console">Console</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="console" className="space-y-4">
            <ScrollArea
              className="h-[400px] w-full rounded-md border bg-black p-4 font-mono text-sm text-green-500"
              ref={outputRef}
            >
              {commandHistory.map((entry, index) => (
                <div key={index} className="mb-2">
                  {entry.command && (
                    <div className="flex items-center text-white">
                      <ChevronRight className="mr-1 h-3 w-3" />
                      <span>{entry.command}</span>
                    </div>
                  )}
                  <div className={`ml-4 whitespace-pre-wrap ${entry.success ? "text-green-500" : "text-red-500"}`}>
                    {entry.output}
                  </div>
                </div>
              ))}
              {processing && (
                <div className="flex items-center ml-4">
                  <div className="animate-pulse">Processing...</div>
                </div>
              )}
            </ScrollArea>

            <form onSubmit={handleSubmit} className="relative">
              <Input
                ref={inputRef}
                value={input}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder="Type a command..."
                disabled={processing}
                className="font-mono"
                autoComplete="off"
              />
              {showSuggestions && (
                <div className="absolute top-full left-0 right-0 z-10 mt-1 rounded-md border bg-background shadow-lg">
                  {suggestions.map((suggestion, index) => (
                    <div
                      key={index}
                      className="cursor-pointer px-3 py-2 hover:bg-accent"
                      onClick={() => applySuggestion(suggestion)}
                    >
                      {suggestion}
                    </div>
                  ))}
                </div>
              )}
            </form>
          </TabsContent>

          <TabsContent value="history">
            <ScrollArea className="h-[450px]">
              <div className="space-y-2">
                {commandHistory
                  .filter((entry) => entry.command)
                  .map((entry, index) => (
                    <div key={index} className="flex items-center justify-between rounded-md border p-3 text-sm">
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm" onClick={() => setInput(entry.command)}>
                          <RefreshCw className="h-3 w-3 mr-1" />
                          <span className="font-mono">{entry.command}</span>
                        </Button>
                      </div>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Clock className="h-3 w-3 mr-1" />
                        {entry.timestamp.toLocaleTimeString()}
                      </div>
                    </div>
                  ))}
                {commandHistory.filter((entry) => entry.command).length === 0 && (
                  <p className="text-center text-muted-foreground py-8">No command history available</p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="settings">
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">Available Commands</h3>
                <div className="grid grid-cols-3 gap-2">
                  {availableCommands.map((cmd, index) => (
                    <div
                      key={index}
                      className="text-sm font-mono cursor-pointer hover:text-primary"
                      onClick={() => setInput(cmd)}
                    >
                      {cmd}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Keyboard Shortcuts</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Up Arrow</div>
                  <div>Previous command</div>
                  <div>Down Arrow</div>
                  <div>Next command</div>
                  <div>Tab</div>
                  <div>Autocomplete command</div>
                  <div>Ctrl+L</div>
                  <div>Clear console</div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        <div className="flex justify-between w-full">
          <span>Type "help" for available commands</span>
          <span>{commandHistory.filter((entry) => entry.command).length} commands executed</span>
        </div>
      </CardFooter>
    </Card>
  )
}
