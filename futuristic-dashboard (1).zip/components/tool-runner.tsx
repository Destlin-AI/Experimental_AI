"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Loader2, Play, RefreshCw } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { toast } from "@/components/ui/use-toast"
import { fetchTools, executeTool } from "@/lib/tool-service"

interface Tool {
  id: string
  name: string
  description: string
  type: string
  config: Record<string, any>
  code: string
  createdAt: string
  updatedAt: string
}

interface ExecutionResult {
  success: boolean
  output: string
  error?: string
  executionTime: number
  timestamp: string
}

export function ToolRunner() {
  const [tools, setTools] = useState<Tool[]>([])
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null)
  const [loading, setLoading] = useState(false)
  const [executing, setExecuting] = useState(false)
  const [result, setResult] = useState<ExecutionResult | null>(null)
  const [inputParams, setInputParams] = useState<Record<string, string>>({})
  const [activeTab, setActiveTab] = useState("run")

  useEffect(() => {
    loadTools()
  }, [])

  const loadTools = async () => {
    setLoading(true)
    try {
      const toolsData = await fetchTools()
      setTools(toolsData)
      if (toolsData.length > 0) {
        setSelectedTool(toolsData[0])
        initializeParams(toolsData[0])
      }
    } catch (error) {
      console.error("Failed to load tools:", error)
      toast({
        title: "Error",
        description: "Failed to load tools. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const initializeParams = (tool: Tool) => {
    if (tool && tool.config && tool.config.params) {
      const initialParams: Record<string, string> = {}
      Object.keys(tool.config.params).forEach((key) => {
        initialParams[key] = tool.config.params[key].default || ""
      })
      setInputParams(initialParams)
    } else {
      setInputParams({})
    }
  }

  const handleToolSelect = (toolId: string) => {
    const tool = tools.find((t) => t.id === toolId)
    if (tool) {
      setSelectedTool(tool)
      initializeParams(tool)
      setResult(null)
    }
  }

  const handleParamChange = (key: string, value: string) => {
    setInputParams((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  const handleExecute = async () => {
    if (!selectedTool) return

    setExecuting(true)
    setResult(null)

    try {
      const executionResult = await executeTool(selectedTool.id, inputParams)
      setResult(executionResult)
    } catch (error) {
      console.error("Failed to execute tool:", error)
      toast({
        title: "Execution Failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      })
    } finally {
      setExecuting(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Tool Runner</span>
          <Button variant="outline" size="sm" onClick={loadTools} disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            <span className="ml-2">Refresh</span>
          </Button>
        </CardTitle>
        <CardDescription>Load and execute saved tools</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">Select Tool</label>
            <Select disabled={loading || tools.length === 0} value={selectedTool?.id} onValueChange={handleToolSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Select a tool" />
              </SelectTrigger>
              <SelectContent>
                {tools.map((tool) => (
                  <SelectItem key={tool.id} value={tool.id}>
                    {tool.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedTool && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-lg font-semibold">{selectedTool.name}</h3>
                  <Badge variant="outline">{selectedTool.type}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{selectedTool.description}</p>
              </div>

              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="run">Run</TabsTrigger>
                  <TabsTrigger value="code">Code</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                </TabsList>

                <TabsContent value="run" className="space-y-4">
                  {selectedTool.config &&
                  selectedTool.config.params &&
                  Object.keys(selectedTool.config.params).length > 0 ? (
                    <div className="space-y-4">
                      <h4 className="text-sm font-medium">Parameters</h4>
                      {Object.entries(selectedTool.config.params).map(([key, value]: [string, any]) => (
                        <div key={key} className="space-y-2">
                          <label className="text-sm font-medium">{value.label || key}</label>
                          <Textarea
                            placeholder={value.placeholder || `Enter ${key}`}
                            value={inputParams[key] || ""}
                            onChange={(e) => handleParamChange(key, e.target.value)}
                            rows={3}
                          />
                          {value.description && <p className="text-xs text-muted-foreground">{value.description}</p>}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">This tool doesn't require any parameters.</p>
                  )}

                  <Button className="w-full" onClick={handleExecute} disabled={executing}>
                    {executing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Executing...
                      </>
                    ) : (
                      <>
                        <Play className="mr-2 h-4 w-4" />
                        Execute Tool
                      </>
                    )}
                  </Button>

                  {result && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Result</h4>
                      <Alert variant={result.success ? "default" : "destructive"}>
                        <AlertTitle>{result.success ? "Success" : "Error"}</AlertTitle>
                        <AlertDescription>Execution time: {result.executionTime}ms</AlertDescription>
                      </Alert>
                      <ScrollArea className="h-[200px] w-full rounded-md border p-4">
                        <pre className="text-sm">{result.output || result.error}</pre>
                      </ScrollArea>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="code">
                  <ScrollArea className="h-[400px] w-full rounded-md border">
                    <pre className="p-4 text-sm">{selectedTool.code}</pre>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="settings">
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium">Tool Information</h4>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <div className="text-sm">Created:</div>
                        <div className="text-sm">{new Date(selectedTool.createdAt).toLocaleString()}</div>
                        <div className="text-sm">Updated:</div>
                        <div className="text-sm">{new Date(selectedTool.updatedAt).toLocaleString()}</div>
                        <div className="text-sm">Type:</div>
                        <div className="text-sm">{selectedTool.type}</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium">Configuration</h4>
                      <ScrollArea className="h-[200px] w-full rounded-md border mt-2">
                        <pre className="p-4 text-sm">{JSON.stringify(selectedTool.config, null, 2)}</pre>
                      </ScrollArea>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <p className="text-xs text-muted-foreground">{tools.length} tools available</p>
      </CardFooter>
    </Card>
  )
}
