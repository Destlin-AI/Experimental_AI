import { type NextRequest, NextResponse } from "next/server"
import { getFileContent, deleteFile, renameFile, getFileStats } from "@/lib/file-service"
import sharp from "sharp"

export async function GET(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const filePath = params.path.join("/")
    const url = new URL(request.url)
    const action = url.searchParams.get("action")

    if (action === "stats") {
      const stats = await getFileStats(filePath)
      return NextResponse.json(stats)
    } else if (action === "preview") {
      // Generate a preview for image files
      const content = await getFileContent(filePath)
      const fileStats = await getFileStats(filePath)

      if (fileStats.type.startsWith("image/")) {
        // Resize image for preview
        const resizedImage = await sharp(content).resize(300, 300, { fit: "inside" }).toBuffer()

        return new NextResponse(resizedImage, {
          headers: {
            "Content-Type": fileStats.type,
            "Content-Disposition": `inline; filename="${fileStats.name}"`,
          },
        })
      } else {
        // Return the file as is for non-image files
        return new NextResponse(content, {
          headers: {
            "Content-Type": fileStats.type,
            "Content-Disposition": `inline; filename="${fileStats.name}"`,
          },
        })
      }
    } else {
      // Return the file content
      const content = await getFileContent(filePath)
      const fileStats = await getFileStats(filePath)

      return new NextResponse(content, {
        headers: {
          "Content-Type": fileStats.type,
          "Content-Disposition": `attachment; filename="${fileStats.name}"`,
        },
      })
    }
  } catch (error) {
    console.error("Error handling file:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to handle file" },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const filePath = params.path.join("/")
    await deleteFile(filePath)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting file:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to delete file" },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const filePath = params.path.join("/")
    const body = await request.json()
    const { newName } = body

    if (!newName) {
      return NextResponse.json({ error: "Missing required field: newName" }, { status: 400 })
    }

    const updatedFile = await renameFile(filePath, newName)

    return NextResponse.json(updatedFile)
  } catch (error) {
    console.error("Error renaming file:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to rename file" },
      { status: 500 },
    )
  }
}
