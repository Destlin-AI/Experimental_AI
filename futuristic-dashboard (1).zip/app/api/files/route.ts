import { type NextRequest, NextResponse } from "next/server"
import { listFiles, createDirectory } from "@/lib/file-service"

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const dir = url.searchParams.get("dir") || ""

    const files = await listFiles(dir)
    return NextResponse.json(files)
  } catch (error) {
    console.error("Error listing files:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to list files" },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { path } = body

    if (!path) {
      return NextResponse.json({ error: "Missing required field: path" }, { status: 400 })
    }

    const directory = await createDirectory(path)
    return NextResponse.json(directory)
  } catch (error) {
    console.error("Error creating directory:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to create directory" },
      { status: 500 },
    )
  }
}
