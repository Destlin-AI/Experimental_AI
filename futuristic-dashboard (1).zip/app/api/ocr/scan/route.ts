import { type NextRequest, NextResponse } from "next/server"
import { processImageWithOCR } from "@/lib/ocr-service"
import { writeFile } from "fs/promises"
import path from "path"
import { v4 as uuidv4 } from "uuid"

export async function POST(request: NextRequest) {
  try {
    // Check if the request is multipart/form-data
    const contentType = request.headers.get("content-type") || ""

    if (contentType.includes("multipart/form-data")) {
      const formData = await request.formData()
      const file = formData.get("file") as File | null
      const language = (formData.get("language") as string) || "eng"
      const enhanceImage = formData.get("enhanceImage") === "true"
      const ocrEngine = (formData.get("ocrEngine") as string) || "standard"

      if (!file) {
        return NextResponse.json({ error: "No file provided" }, { status: 400 })
      }

      // Check if the file is an image
      if (!file.type.startsWith("image/")) {
        return NextResponse.json({ error: "File must be an image" }, { status: 400 })
      }

      // Convert file to buffer
      const buffer = Buffer.from(await file.arrayBuffer())

      // Process the image with OCR
      const result = await processImageWithOCR(buffer, {
        language,
        enhanceImage,
        ocrEngine,
      })

      // Save the processed image to the uploads directory
      const uploadsDir = path.join(process.cwd(), "uploads", "ocr")
      await writeFile(path.join(uploadsDir, `${uuidv4()}_${file.name}`), buffer).catch(() => {
        // If directory doesn't exist, create it and try again
        const fs = require("fs")
        fs.mkdirSync(uploadsDir, { recursive: true })
        return writeFile(path.join(uploadsDir, `${uuidv4()}_${file.name}`), buffer)
      })

      return NextResponse.json({
        success: true,
        text: result.text,
        confidence: result.confidence,
        words: result.words,
      })
    } else {
      // Handle JSON request
      const body = await request.json()
      const { imageUrl, language, enhanceImage, ocrEngine } = body

      if (!imageUrl) {
        return NextResponse.json({ error: "No image URL provided" }, { status: 400 })
      }

      // Fetch the image
      const imageResponse = await fetch(imageUrl)
      if (!imageResponse.ok) {
        return NextResponse.json({ error: "Failed to fetch image from URL" }, { status: 400 })
      }

      const imageBuffer = Buffer.from(await imageResponse.arrayBuffer())

      // Process the image with OCR
      const result = await processImageWithOCR(imageBuffer, {
        language: language || "eng",
        enhanceImage: enhanceImage !== false,
        ocrEngine: ocrEngine || "standard",
      })

      return NextResponse.json({
        success: true,
        text: result.text,
        confidence: result.confidence,
        words: result.words,
      })
    }
  } catch (error) {
    console.error("Error processing OCR:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred during OCR processing",
      },
      { status: 500 },
    )
  }
}
