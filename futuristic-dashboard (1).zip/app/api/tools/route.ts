import { type NextRequest, NextResponse } from "next/server"
import { fetchTools, createTool, updateTool, deleteTool } from "@/lib/tool-service"

export async function GET(request: NextRequest) {
  try {
    const tools = await fetchTools()
    return NextResponse.json(tools)
  } catch (error) {
    console.error("Error fetching tools:", error)
    return NextResponse.json({ error: "Failed to fetch tools" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description, type, code, config } = body

    if (!name || !type || !code) {
      return NextResponse.json({ error: "Missing required fields: name, type, or code" }, { status: 400 })
    }

    const tool = await createTool(name, description || "", type, code, config || {})

    return NextResponse.json(tool)
  } catch (error) {
    console.error("Error creating tool:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to create tool" },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, ...updates } = body

    if (!id) {
      return NextResponse.json({ error: "Missing required field: id" }, { status: 400 })
    }

    const tool = await updateTool(id, updates)

    return NextResponse.json(tool)
  } catch (error) {
    console.error("Error updating tool:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update tool" },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const id = url.searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Missing required query parameter: id" }, { status: 400 })
    }

    await deleteTool(id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting tool:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to delete tool" },
      { status: 500 },
    )
  }
}
