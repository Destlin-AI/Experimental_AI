import { type NextRequest, NextResponse } from "next/server"
import { executeTool } from "@/lib/tool-service"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { toolId, params } = body

    if (!toolId) {
      return NextResponse.json({ error: "Missing required field: toolId" }, { status: 400 })
    }

    const result = await executeTool(toolId, params || {})

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error executing tool:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Failed to execute tool",
        output: error instanceof Error ? error.message : "Failed to execute tool",
        executionTime: 0,
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
