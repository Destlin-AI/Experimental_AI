"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ProtectedRoute } from "@/components/protected-route"
import { ArrowLeft, FolderOpen } from "lucide-react"
import { ToastProvider } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import DragAndDropUploader from "@/components/drag-and-drop-uploader"
import { UploadsManager } from "@/components/uploads-manager"

export default function UploadsPage() {
  const router = useRouter()

  return (
    <ProtectedRoute>
      <ToastProvider>
        <div className="container mx-auto p-4 relative z-10">
          <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm overflow-hidden">
            <CardHeader className="border-b border-slate-700/50 pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="mr-2 text-slate-400 hover:text-slate-100"
                    onClick={() => router.push("/dashboard")}
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </Button>
                  <CardTitle className="text-slate-100 flex items-center">
                    <FolderOpen className="mr-2 h-5 w-5 text-blue-500" />
                    File Management
                  </CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <Tabs defaultValue="browse" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="browse">Browse Files</TabsTrigger>
                  <TabsTrigger value="upload">Upload Files</TabsTrigger>
                </TabsList>
                <TabsContent value="browse">
                  <UploadsManager />
                </TabsContent>
                <TabsContent value="upload">
                  <DragAndDropUploader />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </ToastProvider>
    </ProtectedRoute>
  )
}
