import type { Metadata } from "next"
import { EnhancedConsole } from "@/components/enhanced-console"

export const metadata: Metadata = {
  title: "System Console",
  description: "Execute system commands and view output",
}

export default function ConsolePage() {
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">System Console</h1>
          <p className="text-muted-foreground">Execute system commands and view real-time output</p>
        </div>
      </div>

      <EnhancedConsole />
    </div>
  )
}
