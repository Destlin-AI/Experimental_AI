import type { Metadata } from "next"
import { ToolRunner } from "@/components/tool-runner"

export const metadata: Metadata = {
  title: "Tool Runner",
  description: "Run saved tools and view results",
}

export default function ToolsPage() {
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tool Runner</h1>
          <p className="text-muted-foreground">Load and execute saved tools from your library</p>
        </div>
      </div>

      <div className="grid gap-6">
        <ToolRunner />
      </div>
    </div>
  )
}
