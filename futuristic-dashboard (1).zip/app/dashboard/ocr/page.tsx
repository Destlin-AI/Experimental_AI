"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ProtectedRoute } from "@/components/protected-route"
import { ArrowLeft, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { OCRProcessor } from "@/components/ocr-processor"

export default function OCRPage() {
  const router = useRouter()

  return (
    <ProtectedRoute>
      <div className="container mx-auto p-4 relative z-10">
        <Card className="bg-slate-900/50 border-slate-700/50 backdrop-blur-sm overflow-hidden">
          <CardHeader className="border-b border-slate-700/50 pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Button
                  variant="ghost"
                  size="icon"
                  className="mr-2 text-slate-400 hover:text-slate-100"
                  onClick={() => router.push("/dashboard")}
                >
                  <ArrowLeft className="h-5 w-5" />
                </Button>
                <CardTitle className="text-slate-100 flex items-center">
                  <FileText className="mr-2 h-5 w-5 text-purple-500" />
                  OCR Document Processor
                </CardTitle>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <OCRProcessor standalone={false} />
          </CardContent>
        </Card>
      </div>
    </ProtectedRoute>
  )
}
